import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from server import app
class ApiTests(unittest.TestCase):
 def setUp(self):self.client=app.test_client()
 def test_health(self):self.assertEqual(self.client.get('/health').json['status'],'ok')
 def test_demo(self):
  r=self.client.get('/api/demo');self.assertEqual(r.status_code,200);self.assertTrue(r.json['demo']);self.assertIn('entries',r.json)
 def test_missing_upload(self):self.assertEqual(self.client.post('/api/analyze').status_code,400)
 def test_manifest(self):self.assertEqual(self.client.get('/manifest.webmanifest').status_code,200)
if __name__=='__main__':unittest.main()
