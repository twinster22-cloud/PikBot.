# PikBot — installable PWA research simulator

Independent, dark-themed, mobile-first progressive web app using the **existing PrizePicks AI 3.0 baseline** (`engine.py`). Includes a Flask backend, synthetic demo, CSV analysis, two-pick combinations, optional walk-forward backtesting, and a Home Screen icon.

**Not a live-data app.** No scraping, accounts, real-money placement, calibrated probabilities, validated 75–80% win rate, actual payout models, or guarantees. Entry probabilities multiply individual probabilities under an unverified independence assumption. Same-player and known same-event combinations are rejected. No persistent database. Offline only caches the app shell; predictions need internet/backend.

## Local run (computer)

1. Install Python 3.10+.
2. Extract the ZIP, open a terminal in the `pikbot` directory.
3. Run:
   ```bash
   python -m pip install -r requirements.txt
   python server.py
   ```
4. Visit `http://127.0.0.1:5000` on the computer. Select **Run synthetic demo**.

## Install on iPhone

A Home Screen PWA needs a publicly reachable **HTTPS** address (except localhost on the same device). Running `server.py` on a computer alone does not provide a public iPhone URL.

1. Put the project in a private GitHub repository (exclude any real personal datasets).
2. Deploy to a Python-capable hosting service that supports a Flask web process, such as Render. Build command: `pip install -r requirements.txt`; start command: `gunicorn --bind 0.0.0.0:$PORT server:app`. Set working directory to the project root. Review hosting costs and privacy settings.
3. Open the HTTPS deployment URL in **Safari** on iPhone.
4. Tap **Share** → **Add to Home Screen** → **Add**. Open the **PikBot** icon.
5. The app UI can be cached, but demo analysis and uploaded CSVs require network access.

An Apple App Store listing is **not** included or required. iOS versions and Safari menu wording can vary.

## CSV formats

`history.csv`: `sport,player,stat,date,value`. The `date` must be the timestamp the result was **available**, not just the game start.

`offers.csv`: `sport,player,stat,line,as_of,offer_id,event_id` and optionally `actual` for historical backtesting. `as_of` must reflect the actual available projection timestamp. Use ISO 8601 UTC timestamps, for example `2026-01-10T18:00:00Z`. `offer_id` must uniquely identify the offer; `event_id` should identify its game.

Backtesting groups entries by identical `as_of` timestamps and picks one highest-scoring entry per group. It cannot establish profitability or valid probabilities without real historical as-of offer snapshots, sport-specific calibration, correlation modeling, and payout rules. Entries sharing underlying games may invalidate simple confidence intervals. Don't tune and evaluate on the same time period.

## Testing

Run `python -m unittest discover -s tests -v`. No live network access is needed. `GET /health` is available for deployment health checks.

## Deployment notes

Do not use Flask's development server publicly. Use Gunicorn behind HTTPS. Add authentication and rate limiting before sharing broadly. File uploads are parsed in memory and not persisted by this code; your host may still log request metadata. Keep API credentials server-side if authorized feeds are added later. Review provider terms and local law.


## PikBot branding update
The custom green-and-metallic PB robot logo is included as iPhone touch icon, PWA icons, splash image, and dashboard header. After redeployment, remove and re-add the Home Screen icon if iOS continues showing the old one.
